#!/system/bin/sh
# This script will be executed in post-fs-data mode
# More info in the Magisk Documentation
# https://topjohnwu.github.io/Magisk/guides.html
MODDIR=${0%/*}

# This script will be executed in post-fs-data mode
# More info in the Magisk Documentation
# https://topjohnwu.github.io/Magisk/guides.html
