#!/system/bin/sh
# This script will be executed in late_start service mode
# More info in the Magisk Documentation
# https://topjohnwu.github.io/Magisk/guides.html

# Wait for the boot to complete
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 1
done

# Grant permissions to the oLinky app process to manage configfs
# This allows the app to create, read, write, and manage directories/files
# within the /config/usb_gadget path.
# The "untrusted_app" is the default domain for user-installed apps.
# We are allowing it to interact with the "configfs" type.
magiskpolicy --live "allow untrusted_app configfs dir { create search getattr setattr read write add_name remove_name rmdir }"
magiskpolicy --live "allow untrusted_app configfs file { create getattr setattr read write open }"

# Specifically for Samsung devices, the UDC (USB Device Controller) might have a different label.
# This rule allows the app to write to the UDC file to bind the gadget.
magiskpolicy --live "allow untrusted_app sysfs_usb_supply file { write }"
magiskpolicy --live "allow untrusted_app sysfs file { write }"
